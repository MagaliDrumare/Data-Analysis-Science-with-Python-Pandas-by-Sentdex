#Learning to program with Python 3 
# https://www.youtube.com/watch?v=eXBD2bB9-RA&list=PLQVvvaa0QuDeAams7fkdcwOGBpGdHpXln


##### vidéo 1 : tupples, string, loops 
'''programming_langages = "Python", "Java", "C++", "C#"
or language in programming_langages: 
	print(language)'''


#### video 2 : Lists
'''game = [[0,0,0],
		[0,0,0],
		[0,0,0],]

for row in game : 
	print(row)'''


#### video 5 : Indexes and slices 
'''l =[1,2,3,4]
print(l[1])
print(l[-1])
print(l)
print(l[2:])
l[1]=99
print(l)'''


'''game =[[0,0,0],
		[0,0,0],
		[0,0,0],]

game[0][1]= 1

print("a b c" )
for count, row in enumerate (game):
	print(count, row)'''



#### video 6 : function 
'''game =[[0,0,0],
		[0,0,0],
		[0,0,0],]

def game_board():
	print("a b c" )
	for count, row in enumerate (game):
		print(count, row)

game_board()

game[0][1]= 1

game_board()'''



#### video 7 : parameters 
'''def addition(x,y):
	 return x + y

z = addition(5,8)
z = addition("Hey"," Jude")
print(z)'''



##### video 8 : mutability

'''game =[[0,0,0],
		[0,0,0],
		[0,0,0],]

def game_board(game_map,player, row, column):
 try:
	print("a b c" )
	game[row][column]= player
	for count, row in enumerate(game_map):
		print(count, row)
	return game_map
except: 
	print("something goes wrong")

game_board(game,1,1,4)'''



#### video 9 : Error Handling 
'''game =[[0,0,0],
		[0,0,0],
		[0,0,0],]

def game_board(game_map,player, row, column):
 try:
	 print("a b c" )
	 game[row][column]= player
	 for count, row in enumerate(game_map):
		 print(count, row)
	 return game_map
 except: 
	 print("something goes wrong")

game_board(game,1,1,4)'''

'''game =[[0,0,0],
		[0,0,0],
		[0,0,0],]

def game_board(game_map,player, row, column):
 try:
	 print("a b c" )
	 game[row][column]= player
	 for count, row in enumerate(game_map):
		 print(count, row)
	 return game_map
 except IndexError as e: 
	 print("Error: make sure you input row/column as 0,1 or 2",e)

 except Exception as e:
  	print("Something went very wrong ",e)
 
game_board(game,1,1,4)
game_board(game_board, 1,1,2)'''


#### video 10 : Horizontal Winner
'''game =[[1,1,1],
		[0,2,0],
		[2,2,0],]


def win (current_game): 

	for row in game : 
		print(row)
		if row.count(row[0])==len(row) and row[0}!=0:
			print("Winner!")
win(game)'''


####  video 11 : Vertical Winners 
'''game =[[1,0,1],
		[2,2,0],
		[2,2,0],]

for col in range(len(game)): 
	check = []

	for row in game : 
		check.append(row[col])

	if check.count(check[0]) == len(check) and check[0] != 0:	
		print("Winner")'''

### video 12 : Diagonal Winners
game =[[2,0,1],
	   [2,2,0],
	   [1,2,2],]

diags = []
for col, row in enumerate(reversed(range(len(game)))):
	diags.append(game[row][col])
if diags.count(diags[0]) == len(diags) and diags[0] != 0:	
		print("Winner")

diags = []
for ix in range(len(game)):
	diags.append(game[ix][ix])
if diags.count(diags[0]) == len(diags) and diags[0] != 0:	
		print("Winner2")
















